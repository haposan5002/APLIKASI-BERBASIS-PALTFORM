$(document).ready(function() {
    // Array of possible THR amounts
    const thrAmounts = [
        "Rp 500.000",
        "Rp 1.000.000",
        "Rp 2.500.000",
        "Rp 5.000.000",
        "Paket Umroh!",
        "Voucher Belanja Rp 1.500.000",
        "Rp 50.000 (Tetap Bersyukur!)"
    ];

    // Initialize Modal
    const thrModal = new bootstrap.Modal(document.getElementById('thrModal'), {
        keyboard: false
    });

    // Handle Button Click
    $('#btn-claim-thr').on('click', function() {
        // Add loading state to button
        const originalText = $(this).html();
        $(this).html('<i class="fa-solid fa-spinner fa-spin me-2"></i> Mengambil...');
        $(this).prop('disabled', true);

        // Simulate network request/processing delay
        setTimeout(() => {
            // Randomize THR Amount
            const randomIndex = Math.floor(Math.random() * thrAmounts.length);
            const selectedAmount = thrAmounts[randomIndex];
            
            // Update Modal Content using jQuery
            $('#thr-amount-text').hide().text(selectedAmount).fadeIn(800);

            // Hide loading and restore button
            $(this).html(originalText);
            $(this).prop('disabled', false);

            // Show Modal
            thrModal.show();

            // Fire Confetti Animation
            fireConfetti();
        }, 800);
    });

    // Reset Modal content when closed (optional effect)
    $('#thrModal').on('hidden.bs.modal', function () {
        $('#thr-amount-text').text("Menghitung...");
    });

    // Confetti Function using canvas-confetti
    function fireConfetti() {
        var duration = 3 * 1000;
        var end = Date.now() + duration;

        (function frame() {
            confetti({
                particleCount: 5,
                angle: 60,
                spread: 55,
                origin: { x: 0 },
                colors: ['#c99c33', '#e2b95b', '#ffffff']
            });
            confetti({
                particleCount: 5,
                angle: 120,
                spread: 55,
                origin: { x: 1 },
                colors: ['#c99c33', '#e2b95b', '#ffffff']
            });

            if (Date.now() < end) {
                requestAnimationFrame(frame);
            }
        }());
    }
});

<!DOCTYPE html>
<html>
 <head><title>Latihan 1</title></head>
 <body>
  Nama : <?php echo e($nama); ?> <br/>
  Asal : <?php echo e($asal); ?> <br/>
 </body>
</html>
<?php /**PATH /Users/haposansiregar/Downloads/tugas6/TUGAS  4/latihan-app2/resources/views/v_latihan1.blade.php ENDPATH**/ ?>